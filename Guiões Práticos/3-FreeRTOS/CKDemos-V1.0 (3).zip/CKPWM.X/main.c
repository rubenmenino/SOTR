/* 
 * File:   CKPWM
 * Author: Paulo Pedreiras
 *
 * Created on Jan 28, 2019
 * MPLAB X IDE v5.\0 + XC32 v2.15
 *
 * Target: Digilent chipKIT MAx32 board 
 * Configurations:
 *      HSPLL; CPUCLK=80MHz, PBCLCK=40MHz; Watchdog timer disabled
 *      
 * Overview:
 *  Generates a PWM waveform based on timer 2 / OC1
 *  PWM appears in pin RD0/OC1/INT0
 *  The PWM duty cycle varies from 0 to 100.0%,in steps of 0.1%
 *
 *  Revisions:
 *      2018-02-19: Initial release
 *      2019-01-28: Updated to MPLAB X IDE v5.\0 + XC32 v2.15
 */

#include "../CKCommon/ConfigBits/config_bits.h" // NOTE!! Must precede project file includes

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

#define SYSCLK  80000000L // System clock frequency, in Hz
#define PBCLOCK 40000000L // Peripheral Bus Clock frequency, in Hz

// Defines
#define TPS_256 7 // TCKPS code for 256 pre-scaler

/*
 * 
 */
int main(int argc, char** argv) {
     // Variable declarations;
    int intensity = 0, i=0;
    
     // Set RD0 as digital output
    TRISDbits.TRISD0 = 0;
    PORTDbits.RD0 = 1;
  
    // Set timer
    T2CONbits.ON = 0; // Stop timer
    IFS0bits.T2IF=0; // Reset interrupt flag    
    T2CONbits.TCKPS = TPS_256; //Select pre-scaler
    T2CONbits.T32 = 0; // 16 bit timer operation
    PR2=1000; // Compute PR value
    TMR2=0;

    // Set OC1
    OC1CONbits.OCM = 6; // OCM = 0b110 : OC1 in PWM mode,
    OC1CONbits.OCTSEL=0; // Timer 2 is clock source of OCM
    OC1RS=0; // Compute OC1xRS value
    OC1CONbits.ON=1;     // Enable OC1

    // Start PWM generation
    T2CONbits.TON=1; // Start the timer

    // Main loop
    while(1)
    {
        for(i=0;i<1000;i++); // Pause a little bit, to make it eye-observable
        if(intensity < 1000) // Increase duty-cycle, if possible
            intensity ++; 
        else
            intensity = 0; // If DC at max, restart from 0;
        
        OC1RS = intensity;  // Update DC
        
    }

    return (EXIT_SUCCESS);
    
}

