/* 
 * File:   CKExtInt
 * Author: Paulo Pedreiras
 *
 * Created on Jan 28, 2019
 * MPLAB X IDE v5.10 + XC32 v2.15
 *
 * Target: Digilent chipKIT MAx32 board 
 * Configurations:
 *      HSPLL; CPUCLK=80MHz, PBCLCK=40MHz; Watchdog timer disabled
 *      
 * Overview:
 *     Illustrates the use of an external interrupt
 *     Also illustrates how stdout can be redirected to the UART  
 *
 *  Revisions:
 *      2018-02-19: Initial release
 *      2019-01-28: Updated to MPLAB X IDE v5.10 + XC32 v2.15
 */

#include "../CKCommon/ConfigBits/config_bits.h" // NOTE!! Must precede project file includes

#include <xc.h>
#include <sys/attribs.h>
#include <stdio.h>
#include <stdlib.h>
#include "../CKCommon/UART/uart.h" 

#define SYSCLK  80000000L // System clock frequency, in Hz
#define PBCLOCK 40000000L // Peripheral Bus Clock frequency, in Hz

// Global vars
volatile int int1_int_flag; // Flag to signal the occurrence of an int. 
                            // ***Note the volatile prefix*** 

// Declare ISR. Be careful to put the right vector and match the IPL with 
// the one defined on the peripheral set-up
void __ISR (_EXTERNAL_1_VECTOR, IPL1AUTO) ExtInt1ISR(void)
{
    int1_int_flag = 1;
    IFS0bits.INT1IF = 0; // Reset interrupt flag
}


/*
 * 
 */
int main(int argc, char** argv) {
    // Var declaration
    int nints=0; // Accumulates the # of interrupts
    

    // Init UART and redirect tdin/stdot/stderr to UART
    if(UartInit(PBCLOCK, 115200) != UART_SUCCESS) {
        PORTAbits.RA3 = 1; // If Led active error initializing UART
        while(1);
    }
    __XC_UART = 1; /* Redirect stdin/stdout/stderr to UART1*/
    
    /* Set Interrupt Controller for multi-vector mode */
    INTCONSET = _INTCON_MVEC_MASK;
    
    /* Enable Interrupt Exceptions */
    // set the CP0 status IE bit high to turn on interrupts globally
    __builtin_enable_interrupts();
    

    // Configure Int 1 (vector numbers defined in p32mx795512h.h)
    TRISDbits.TRISD8 = 1; // Set pin as input
    INTCONbits.INT1EP = 0; // Generat interrupts on {rising edge-1 falling edge - 0}
    IFS0bits.INT1IF = 0; // Reset int flag
    IPC1bits.INT1IP = 1; // Set interrupt priority (1..7) *** Set equal to ilpx above
    IEC0bits.INT1IE = 1; // Enable Int1 interrupts


    // Welcome message
    printf("Generates a message for each level change in Int1 (RD8)\n\r");

    // Main loop
    while (1) {
        while (int1_int_flag == 0); // Wait until Int generated
        printf("Int1 generated!(%d)\n\r", ++nints); // Message to USART
        int1_int_flag = 0; // Reset int 1 flag
    }

    return (EXIT_SUCCESS);
    
    
    
}


