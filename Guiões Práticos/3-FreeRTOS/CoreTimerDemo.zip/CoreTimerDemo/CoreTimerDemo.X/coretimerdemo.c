/* 
 * File:   ledblink.c
 * Author: Paulo Pedreiras
 *
 * Created on March 10, 2014, 1:05 PM
 * MPLAB X IDE v1.70 + XC32 v1.20
 *
 * Target: DETPIC32 board 
 * Configurations:
 *      HSPLL; CPUCLK=80MHz, PBCLCK=40MHz; Watchdog timer disabled
 *      USART: 115200,8,N,1
 * 
 * Test CoreTimer - used to blink the led on port D0
 *
 *  *  Revisions:
 *      Mar/2015:
 *          - supress PLIB warnings added
 *
 *
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#define _SUPPRESS_PLIB_WARNING 1
#include <p32xxxx.h>
#include <plib.h>

#define SYSCLK 80000000L // System clock frequency, in Hz
/*
 * 
 */

void Delay_ms(unsigned int dms)
/*
 * Core timer uses a 32 bit HW register. Max value is 4,294,967,295 and counts at FOSC/2
 * For a 80 MHz FOSC the core timer ticks every 25 nS and will roll over in 107.374 seconds.
 * OpenCoreTimer() and UpdateCoreTimer() are used only if you want to generate interrupts when the
 * core timer reaches a given value.  None of the functions alters the value of the core timer.
 * You don't have to use them to use ReadCoreTimer().
 *
 * Info: PIC32MX Family reference manual, Section 2.2.3
 *
 * 1 tick - 25ns
 * x ticks - 1ms
 * x=1e-3/25e-9=0.04e6=40000 - CoreTimet ticks that correspond to one milisecond
 *
 */
{
    unsigned int t;
    t=ReadCoreTimer()+40000*dms;
    while(ReadCoreTimer() < t);
}


int main(int argc, char** argv) {
    // Variable declarations;
    unsigned int i, j;

   // Performance optimization (flash access time, enable instruct and data cache,... and PBClock setup
    SYSTEMConfigPerformance(SYSCLK);
    mOSCSetPBDIV( OSC_PB_DIV_2 ); // This is necessary since SYSTEMConfigPerformance defaults FPBDIV to DIV_1

    // Set D0 as outpout
    TRISDbits.TRISD0 = 0;

    // Loop
    while (1) {
        // Toggle D0
        PORTDbits.RD0 = !PORTDbits.RD0;

        // Pause 1 second
        Delay_ms(1000);
    }
    
    return (EXIT_SUCCESS);
}

