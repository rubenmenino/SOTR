/* 
 * File:   CKDigitalIO
 * Author: Paulo Pedreiras
 *
 * Created on Jan 28, 2019
 * MPLAB X IDE v5.\0 + XC32 v2.15
 *
 * Target: Digilent chipKIT MAx32 board 
 * Configurations:
 *      HSPLL; CPUCLK=80MHz, PBCLCK=40MHz; Watchdog timer disabled
 *      
 * Overview:
 *      Configures PortD RD0 as output and RD1 as input
 *      Cjecks the logical value of RD1 and sets RD0 accordingly
 *
 *  Revisions:
 *      2017-10-15: Initial release
 *      2019-01-28: Updated for MPlab X5.1 + XC32 V2.15
 */

#include "../CKCommon/ConfigBits/config_bits.h" // NOTE!! Must precede project file includes

#include <xc.h>

/*
 * 
 */
int main(int argc, char** argv) {
    // Set PORTD IOs
    TRISDbits.TRISD0 = 0; // D0 as digital output
    TRISDbits.TRISD1 = 1; // D1 as digital input

    // Main loop
    while(1) {
        
        // Set RD0 according with RD1
        PORTDbits.RD0 = PORTDbits.RD1;
    }

    return (EXIT_SUCCESS);
}

